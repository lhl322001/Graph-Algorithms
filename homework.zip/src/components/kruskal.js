function kruskal(graph) {
    let sequence = [];

    let n = graph.vertexes.length;
    let edges = graph.edges;
    edges.sort(function (a, b) {
        return a.dist - b.dist;
    })
    let par = new Array(n);
    for (let i = 0; i < n; i++) {
        par[i] = i;
    }
    function find(x) {
        return par[x] == x ? x : par[x] = find(par[x]);
    }

    let cnt = 0;
    edges.forEach((edge, index) => {
        sequence.push({ type: "activate", u: edge.from, v: edge.to });
        let u = find(edge.from);
        let v = find(edge.to);
        if (u != v) {
            sequence.push({ type: "selectEdge", index: index });
            par[u] = v;
            if (++cnt == n - 1) {
                return sequence;
            }
        }
        else {
            sequence.push({ type: "deactivate", u: edge.from, v: edge.to });
        }
    });

    return sequence;
}

export default kruskal;