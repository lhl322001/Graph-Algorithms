<template>
  <div class="graph-view">
    <div
      class="edge"
      v-for="(edge,index) in edgesDisp"
      :key="index"
      v-bind:style="{
          width: edge.width,
          transform: edge.transform,
          top: edge.top,
          left: edge.left,
          borderTopColor: edge.color
        }"
    ></div>
    <div
      class="vertex"
      v-for="(vertex,index) in vertexesDisp"
      :key="index"
      v-bind:style="{left:vertex.left,top:vertex.top,backgroundColor:vertex.color}"
    >{{ vertex.index }}</div>
    <el-button type="primary" round @click="showKruskal()">Kruskal</el-button>
    <el-button type="primary" round @click="showPrim()">Prim</el-button>
    
  </div>
</template>

<script>
import kruksal from "./kruskal.js";
import prim from "./prim.js";

export default {
  name: "GraphView",
  props: {
    graph: Object,
  },
  computed: {
    vertexesDisp: function () {
      const activeVertexColor = "aliceblue";
      const normalVertexColor = "#42b983";
      const lockVertexColor = "#66b1ff";

      let vertexesDisp = [];
      console.log(this.vertexes.length);
      for (let i = 0; i < this.vertexes.length; i++) {
        let element = this.vertexes[i];
        vertexesDisp.push({
          index: i,
          left: element.x + "px",
          top: element.y + "px",
          color: element.isActive
            ? activeVertexColor
            : element.isLocked
            ? lockVertexColor
            : normalVertexColor,
        });
      }
      return vertexesDisp;
    },
    edgesDisp: function () {
      let edgesDisp = [];
      this.edges.forEach((edge) => {
        let u = this.graph.vertexes[edge.from];
        let v = this.graph.vertexes[edge.to];

        let dist = Math.sqrt(
          (u.x - v.x) * (u.x - v.x) + (u.y - v.y) * (u.y - v.y)
        );
        let angle = Math.atan2(v.y - u.y, v.x - u.x);
        const activeEdgeColor = "#000";
        const normalEdgeColor = "darkgray";
        edgesDisp.push({
          width: dist + "px",
          transform: "rotate(" + angle + "rad)",
          left: u.x + "px",
          top: u.y + "px",
          color: edge.isSelected ? activeEdgeColor : normalEdgeColor,
        });
      });
      return edgesDisp;
    },
    edgeClassObject() {
      return {
        "edge-selected": this.isSelected,
      };
    },
  },
  created() {
    this.reset();
  },
  methods: {
    reset() {
      this.vertexes = [];
      this.edges = [];
      this.graph.vertexes.forEach((element) => {
        this.vertexes.push({
          x: element.x,
          y: element.y,
          isActive: false,
          isLocked: false,
        });
      });
      this.graph.edges.forEach((element) => {
        this.edges.push({
          from: element.from,
          to: element.to,
          dist: element.dist,
          isSelected: false,
        });
      });
      if (this.animationHandle !== null) {
        clearInterval(this.animationHandle);
        this.animationHandle = null;
      }
      this.stepNum = 0;
    },
    showKruskal() {
      this.reset();
      this.operations = kruksal(this.graph);
      console.log(this.operations);
      this.animationHandle = setInterval(this.animationStep, 500);
    },
    showPrim() {
      this.reset();
      this.operations = prim(this.graph);
      console.log(this.operations);
      this.animationHandle = setInterval(this.animationStep, 500);
    },
    animationStep() {
      if (this.stepNum >= this.operations.length) {
        clearInterval(this.animationHandle);
        this.animationHandle = null;
        return;
      }
      let curOpt = this.operations[this.stepNum];
      //console.log(curOpt);
      if (curOpt.type === "activate") {
        this.vertexes[curOpt.u].isActive = true;
        this.vertexes[curOpt.v].isActive = true;
      } else if (curOpt.type === "deactivate") {
        this.vertexes[curOpt.u].isActive = false;
        this.vertexes[curOpt.v].isActive = false;
      } else if (curOpt.type === "selectEdge") {
        let e = this.edges[curOpt.index];
        this.vertexes[e.from].isActive = false;
        this.vertexes[e.to].isActive = false;
        this.vertexes[e.from].isLocked = true;
        this.vertexes[e.to].isLocked = true;
        this.edges[curOpt.index].isSelected = true;
        console.log(e.from, e.to);
        console.log(this.edges[curOpt.index].isSelected);
      }
      this.stepNum++;
    },
  },
  data: function () {
    return {
      vertexes: [],
      edges: [],
      operations: [],
      stepNum: 0,
      animationHandle: null,
    };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}

.vertex {
  position: absolute;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  color: #000;
  background-color: #42b983;
  transform: translateX(-50%) translateY(-50%);
}

.edge {
  position: absolute;
  height: 10px;
  transform-origin: top left;
  border-top: 2px red solid;
}
</style>
